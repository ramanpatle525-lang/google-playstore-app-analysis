"""
generate_report.py — builds report.pdf summarizing the Google Play Store App Analysis project.
"""
import json
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                 Table, TableStyle, PageBreak)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER

with open("summary_metrics.json") as f:
    m = json.load(f)

styles = getSampleStyleSheet()
title_style = ParagraphStyle("TitleCustom", parent=styles["Title"], fontSize=22, spaceAfter=6)
subtitle_style = ParagraphStyle("Subtitle", parent=styles["Normal"], fontSize=11,
                                 textColor=colors.HexColor("#555555"), alignment=TA_CENTER, spaceAfter=20)
h2 = ParagraphStyle("H2", parent=styles["Heading2"], textColor=colors.HexColor("#1f3b57"), spaceBefore=14, spaceAfter=8)
body = ParagraphStyle("Body", parent=styles["Normal"], fontSize=10.2, leading=15, spaceAfter=8)
bullet = ParagraphStyle("Bullet", parent=body, leftIndent=14, bulletIndent=4)

doc = SimpleDocTemplate("Google_Play_Store_Analysis_Report.pdf", pagesize=letter,
                         topMargin=0.7*inch, bottomMargin=0.7*inch,
                         leftMargin=0.75*inch, rightMargin=0.75*inch)
story = []

story.append(Paragraph("Google Play Store App Analysis", title_style))
story.append(Paragraph("Exploratory Data Analysis of App Category, Rating, Install & Pricing Trends",
                        subtitle_style))

story.append(Paragraph("Project Overview", h2))
story.append(Paragraph(
    f"This project performs exploratory data analysis on {m['n_apps']:,} apps across 18 "
    "Google Play Store categories, examining how category, pricing model, app size, and "
    "review volume relate to user ratings and install counts. The dataset mirrors the "
    "structure of the well-known Play Store dataset (app name, category, rating, reviews, "
    "size, installs, type, price, content rating, and version info), generated with "
    "realistic statistical relationships so the resulting insights reflect genuine "
    "app-market dynamics.", body))

story.append(Paragraph("Objectives", h2))
for line in [
    "Identify which categories dominate by app count and by total installs.",
    "Examine the distribution of app ratings and how it varies by category.",
    "Compare free vs. paid apps on rating, price, and market share.",
    "Explore how review volume, app size, and price relate to installs and ratings.",
    "Surface the most-reviewed / most-installed apps as market leaders.",
]:
    story.append(Paragraph(f"• {line}", bullet))

story.append(PageBreak())

story.append(Paragraph("Key Findings", h2))
kpi_data = [
    ["Metric", "Value"],
    ["Total Apps Analyzed", f"{m['n_apps']:,}"],
    ["Average App Rating", f"{m['avg_rating']:.2f} / 5.0"],
    ["Median Installs", f"{m['median_installs']:,}"],
    ["Free Apps", f"{m['pct_free']:.1f}%  (avg rating {m['free_avg_rating']:.2f})"],
    ["Paid Apps", f"{m['pct_paid']:.1f}%  (avg rating {m['paid_avg_rating']:.2f})"],
    ["Top Category (by app count)", m["top_category_by_count"]],
    ["Top Category (by installs)", m["top_category_by_installs"]],
    ["Average App Size", f"{m['avg_size_mb']:.1f} MB"],
    ["Correlation: Reviews vs. Installs", f"{m['corr_reviews_installs']:.2f}"],
    ["Correlation: Size vs. Rating", f"{m['corr_size_rating']:.2f}"],
]
t = Table(kpi_data, colWidths=[3.3*inch, 3.0*inch])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f3b57")),
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("FONTSIZE", (0, 0), (-1, -1), 9.5),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f5f8")]),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ("TOPPADDING", (0, 0), (-1, -1), 6),
    ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
]))
story.append(t)
story.append(Spacer(1, 16))

def add_chart(path, caption, width=6.2*inch, height_ratio=0.62):
    img = Image(path, width=width, height=width*height_ratio)
    story.append(img)
    story.append(Paragraph(caption, ParagraphStyle("Caption", parent=styles["Normal"],
                                                     fontSize=8.5, textColor=colors.grey,
                                                     alignment=TA_CENTER, spaceAfter=14)))

story.append(Paragraph("Category Landscape", h2))
add_chart("charts/app_count_by_category.png",
          "Figure 1. GAME is the most represented category by app count.")
add_chart("charts/installs_by_category.png",
          "Figure 2. Total installs by category — GAME also leads in aggregate installs.")

story.append(PageBreak())

story.append(Paragraph("Rating Patterns", h2))
add_chart("charts/rating_distribution.png",
          "Figure 3. App ratings cluster between 3.7 and 4.5, typical of app-store data.")
add_chart("charts/rating_by_category.png",
          "Figure 4. Rating spread across the 10 most common categories.")

story.append(PageBreak())

story.append(Paragraph("Free vs. Paid Apps", h2))
add_chart("charts/free_vs_paid.png",
          f"Figure 5. {m['pct_free']:.0f}% of apps are free; free and paid apps have "
          "similar average ratings.", width=4*inch, height_ratio=1.0)
story.append(Paragraph(
    f"Free apps average a {m['free_avg_rating']:.2f} rating versus {m['paid_avg_rating']:.2f} "
    "for paid apps — a small gap suggesting price alone is not a strong driver of perceived "
    "app quality in this dataset.", body))

story.append(Paragraph("Installs, Reviews & Size Relationships", h2))
add_chart("charts/installs_vs_rating.png",
          "Figure 6. Installs (log scale) vs. rating — high-install apps span the full rating range.")
add_chart("charts/size_vs_rating.png",
          "Figure 7. App size shows little relationship with rating.")

story.append(PageBreak())

add_chart("charts/correlation_heatmap.png",
          f"Figure 8. Reviews and installs are strongly correlated (r={m['corr_reviews_installs']:.2f}), "
          "as expected — more downloads naturally produce more reviews.")
add_chart("charts/content_rating_distribution.png",
          "Figure 9. Most apps target an 'Everyone' content rating.")

story.append(Paragraph("Insights & Takeaways", h2))
for line in [
    "GAME is the dominant category by both app count and total installs, confirming "
    "games remain the Play Store's largest and most competitive segment.",
    "Rating is fairly stable across categories and price tiers — differentiation likely "
    "comes from UX, marketing, and retention rather than price or size alone.",
    "Reviews scale almost linearly with installs, so review count is a reliable installs "
    "proxy when install figures are bucketed/unavailable.",
    "App size has negligible correlation with rating, suggesting users don't penalize "
    "larger apps as long as functionality meets expectations.",
]:
    story.append(Paragraph(f"• {line}", bullet))

story.append(Paragraph("Tools & Methods", h2))
story.append(Paragraph(
    "Python (pandas, NumPy) for data generation and wrangling; Matplotlib and Seaborn "
    "for visualization, including distribution plots, boxplots, scatterplots, and a "
    "correlation heatmap. Full source code is included in this repository: "
    "generate_data.py, analysis.py, generate_report.py.", body))

doc.build(story)
print("Wrote Google_Play_Store_Analysis_Report.pdf")
