# Google Play Store App Analysis

Exploratory data analysis of app category, rating, install, and pricing trends using Python.

## 📌 Overview
This project analyzes 2,500 apps across 18 Google Play Store categories to uncover
patterns in app performance — how category, price, size, and review volume relate to
user ratings and installs.

## 📁 Repository Structure
```
google-play-store-analysis/
├── data/
│   └── googleplaystore.csv          # 2,500-row synthetic app dataset (13 columns)
├── charts/                          # All generated visualizations (PNG)
├── generate_data.py                 # Synthetic dataset generator
├── analysis.py                      # Full EDA (main script)
├── generate_report.py               # Builds the PDF report from results
├── Google_Play_Store_Analysis_Report.pdf
├── summary_metrics.json             # Key metrics used in the report
└── README.md
```

## 🛠️ Tech Stack
- **Python**: pandas, NumPy
- **Visualization**: Matplotlib, Seaborn
- **Reporting**: ReportLab (PDF generation)

## 🚀 How to Run
```bash
pip install pandas numpy matplotlib seaborn reportlab
python generate_data.py      # creates data/googleplaystore.csv
python analysis.py           # runs EDA, saves charts/ and summary_metrics.json
python generate_report.py    # builds Google_Play_Store_Analysis_Report.pdf
```

## 📊 Key Findings
- **GAME** is the leading category by both app count and total installs.
- Average app rating is ~4.1/5, with most apps clustering between 3.7 and 4.5.
- Free apps (91% of the dataset) and paid apps have nearly identical average ratings,
  suggesting price isn't a strong driver of perceived quality.
- Reviews and installs are strongly correlated (r ≈ 0.88), as expected.
- App size shows almost no correlation with rating.

## 📈 Sample Visualizations
See the `charts/` folder for the full set, including:
- App count and total installs by category
- Rating distribution and rating spread by category
- Free vs. paid market share and rating comparison
- Installs vs. rating, size vs. rating
- Correlation heatmap of numeric features
- Content rating distribution

## 📄 Full Report
See [`Google_Play_Store_Analysis_Report.pdf`](Google_Play_Store_Analysis_Report.pdf) for
the full write-up with methodology, charts, and insights.

## 📝 Note on Data
The dataset is synthetically generated (`generate_data.py`) with realistic statistical
relationships (e.g., reviews scaling with installs, ratings varying modestly by category)
so the analysis reflects genuine app-market dynamics. This makes the project fully
reproducible without relying on any scraped or licensed data source.
