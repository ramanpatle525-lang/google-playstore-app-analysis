"""
generate_data.py
Generates a realistic synthetic Google Play Store dataset (mirrors the structure
of the well-known Play Store Kaggle dataset) for EDA purposes.
"""
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

np.random.seed(7)

N = 2500

categories = ["GAME", "COMMUNICATION", "TOOLS", "PRODUCTIVITY", "SOCIAL", "PHOTOGRAPHY",
              "EDUCATION", "BUSINESS", "LIFESTYLE", "FINANCE", "HEALTH_AND_FITNESS",
              "SHOPPING", "TRAVEL_AND_LOCAL", "ENTERTAINMENT", "FOOD_AND_DRINK",
              "NEWS_AND_MAGAZINES", "MUSIC_AND_AUDIO", "VIDEO_PLAYERS"]

cat_weights = np.array([0.16, 0.06, 0.09, 0.06, 0.07, 0.04, 0.06, 0.05, 0.05, 0.04,
                         0.05, 0.05, 0.04, 0.06, 0.03, 0.03, 0.03, 0.03])
cat_weights = cat_weights / cat_weights.sum()

content_ratings = ["Everyone", "Everyone 10+", "Teen", "Mature 17+"]
content_weights = [0.62, 0.13, 0.20, 0.05]

genres_map = {
    "GAME": ["Action", "Arcade", "Puzzle", "Casual", "Strategy", "Racing"],
    "COMMUNICATION": ["Communication"],
    "TOOLS": ["Tools"],
    "PRODUCTIVITY": ["Productivity"],
    "SOCIAL": ["Social"],
    "PHOTOGRAPHY": ["Photography"],
    "EDUCATION": ["Education"],
    "BUSINESS": ["Business"],
    "LIFESTYLE": ["Lifestyle"],
    "FINANCE": ["Finance"],
    "HEALTH_AND_FITNESS": ["Health & Fitness"],
    "SHOPPING": ["Shopping"],
    "TRAVEL_AND_LOCAL": ["Travel & Local"],
    "ENTERTAINMENT": ["Entertainment"],
    "FOOD_AND_DRINK": ["Food & Drink"],
    "NEWS_AND_MAGAZINES": ["News & Magazines"],
    "MUSIC_AND_AUDIO": ["Music & Audio"],
    "VIDEO_PLAYERS": ["Video Players & Editors"],
}

install_buckets = [0, 100, 500, 1000, 5000, 10000, 50000, 100000, 500000,
                    1000000, 5000000, 10000000, 50000000, 100000000, 500000000, 1000000000]
install_probs = np.array([0.02, 0.04, 0.04, 0.08, 0.08, 0.10, 0.10, 0.12, 0.10,
                           0.11, 0.08, 0.06, 0.03, 0.02, 0.015, 0.005])
install_probs = install_probs / install_probs.sum()

app_name_prefixes = ["Quick", "Super", "Easy", "Smart", "Pro", "My", "All-in-One", "Ultra",
                      "Daily", "Simple", "Mega", "Fast", "Prime", "Go", "Live"]
app_name_suffixes = ["App", "Hub", "Manager", "Tracker", "Studio", "Planner", "Box",
                      "Zone", "Space", "Lab", "Master", "Plus", "Now", "Kit"]

start_date = datetime(2018, 1, 1)
end_date = datetime(2024, 6, 30)
date_range_days = (end_date - start_date).days

rows = []
for i in range(1, N + 1):
    category = np.random.choice(categories, p=cat_weights)
    genre = np.random.choice(genres_map[category])
    app_name = f"{np.random.choice(app_name_prefixes)} {category.title().replace('_', ' ')} {np.random.choice(app_name_suffixes)} {i}"

    installs = int(np.random.choice(install_buckets, p=install_probs))
    # reviews roughly scale with installs (with noise), capped below installs
    reviews = int(np.clip(installs * np.random.uniform(0.001, 0.05), 0, installs))

    # rating: games/social skew slightly lower variance, more reviews -> more stable rating
    base_rating = np.random.normal(4.1, 0.45)
    if category == "GAME":
        base_rating -= 0.05
    rating = float(np.clip(base_rating, 1.0, 5.0))
    rating = round(rating, 1)

    is_paid = np.random.choice([0, 1], p=[0.92, 0.08])
    app_type = "Paid" if is_paid else "Free"
    price = round(np.random.uniform(0.99, 29.99), 2) if is_paid else 0.0

    size_mb = round(np.clip(np.random.lognormal(mean=2.8, sigma=0.9), 1, 500), 1)

    last_updated = start_date + timedelta(days=np.random.randint(0, date_range_days))

    major = np.random.randint(1, 9)
    minor = np.random.randint(0, 20)
    patch = np.random.randint(0, 20)
    current_ver = f"{major}.{minor}.{patch}"

    android_ver_options = ["4.1 and up", "4.4 and up", "5.0 and up", "6.0 and up",
                            "7.0 and up", "8.0 and up", "9.0 and up", "10 and up",
                            "Varies with device"]
    android_ver = np.random.choice(android_ver_options)

    content_rating = np.random.choice(content_ratings, p=content_weights)

    rows.append({
        "app_name": app_name,
        "category": category,
        "genre": genre,
        "rating": rating,
        "reviews": reviews,
        "size_mb": size_mb,
        "installs": installs,
        "type": app_type,
        "price_usd": price,
        "content_rating": content_rating,
        "last_updated": last_updated.strftime("%Y-%m-%d"),
        "current_ver": current_ver,
        "android_ver": android_ver,
    })

df = pd.DataFrame(rows)
df.to_csv("data/googleplaystore.csv", index=False)
print(f"Generated {len(df)} rows -> data/googleplaystore.csv")
print(df.head())
