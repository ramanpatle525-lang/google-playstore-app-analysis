"""
analysis.py
Google Play Store App Analysis — Exploratory Data Analysis
------------------------------------------------------------
Identifies trends in category popularity, ratings, installs, pricing,
and app size to surface app-performance insights.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
import json

sns.set_theme(style="whitegrid")
PALETTE = "viridis"

df = pd.read_csv("data/googleplaystore.csv", parse_dates=["last_updated"])

print("="*60)
print("DATA OVERVIEW")
print("="*60)
print(df.shape)
print(df.isna().sum().sum(), "missing values")
print(df.describe(include="all").T[["count", "mean", "std", "min", "max"]].head(10))

# ---------------------------------------------------------
# App count & installs by category
# ---------------------------------------------------------
cat_counts = df["category"].value_counts()
plt.figure(figsize=(9, 6))
sns.barplot(x=cat_counts.values, y=cat_counts.index, palette=PALETTE)
plt.title("Number of Apps by Category")
plt.xlabel("App Count")
plt.tight_layout()
plt.savefig("charts/app_count_by_category.png", dpi=150)
plt.close()

installs_by_cat = df.groupby("category")["installs"].sum().sort_values(ascending=False)
plt.figure(figsize=(9, 6))
sns.barplot(x=installs_by_cat.values, y=installs_by_cat.index, palette=PALETTE)
plt.title("Total Installs by Category")
plt.xlabel("Total Installs")
plt.tight_layout()
plt.savefig("charts/installs_by_category.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# Rating distribution
# ---------------------------------------------------------
plt.figure(figsize=(8, 5))
sns.histplot(df["rating"], bins=25, kde=True, color="#3b6fa0")
plt.title("Distribution of App Ratings")
plt.xlabel("Rating (out of 5)")
plt.tight_layout()
plt.savefig("charts/rating_distribution.png", dpi=150)
plt.close()

# Rating by category (top 10 by count)
top_cats = cat_counts.head(10).index
plt.figure(figsize=(10, 6))
sns.boxplot(data=df[df["category"].isin(top_cats)], x="rating", y="category",
            palette=PALETTE, orient="h")
plt.title("Rating Spread by Category (Top 10 Categories by App Count)")
plt.xlabel("Rating")
plt.ylabel("")
plt.tight_layout()
plt.savefig("charts/rating_by_category.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# Free vs Paid
# ---------------------------------------------------------
type_counts = df["type"].value_counts()
plt.figure(figsize=(5.5, 5.5))
plt.pie(type_counts.values, labels=type_counts.index, autopct="%1.1f%%",
        colors=["#3b6fa0", "#d1495b"], startangle=90)
plt.title("Free vs Paid Apps")
plt.tight_layout()
plt.savefig("charts/free_vs_paid.png", dpi=150)
plt.close()

paid_avg_rating = df[df["type"] == "Paid"]["rating"].mean()
free_avg_rating = df[df["type"] == "Free"]["rating"].mean()

# ---------------------------------------------------------
# Installs vs Rating
# ---------------------------------------------------------
plt.figure(figsize=(8, 6))
sns.scatterplot(data=df.sample(min(800, len(df)), random_state=1),
                 x="rating", y="installs", hue="type", alpha=0.5,
                 palette={"Free": "#3b6fa0", "Paid": "#d1495b"})
plt.yscale("log")
plt.title("Installs (log scale) vs Rating")
plt.xlabel("Rating")
plt.ylabel("Installs (log scale)")
plt.tight_layout()
plt.savefig("charts/installs_vs_rating.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# App size vs rating
# ---------------------------------------------------------
plt.figure(figsize=(8, 6))
sns.scatterplot(data=df.sample(min(800, len(df)), random_state=1),
                 x="size_mb", y="rating", alpha=0.5, color="#3b6fa0")
plt.title("App Size (MB) vs Rating")
plt.xlabel("Size (MB)")
plt.ylabel("Rating")
plt.tight_layout()
plt.savefig("charts/size_vs_rating.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# Correlation heatmap of numeric features
# ---------------------------------------------------------
numeric_cols = ["rating", "reviews", "size_mb", "installs", "price_usd"]
corr = df[numeric_cols].corr()
plt.figure(figsize=(7, 6))
sns.heatmap(corr, annot=True, cmap="coolwarm", center=0, fmt=".2f")
plt.title("Correlation Heatmap: Numeric App Features")
plt.tight_layout()
plt.savefig("charts/correlation_heatmap.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# Content rating distribution
# ---------------------------------------------------------
content_counts = df["content_rating"].value_counts()
plt.figure(figsize=(7, 5))
sns.barplot(x=content_counts.index, y=content_counts.values, palette=PALETTE)
plt.title("App Count by Content Rating")
plt.ylabel("App Count")
plt.tight_layout()
plt.savefig("charts/content_rating_distribution.png", dpi=150)
plt.close()

# ---------------------------------------------------------
# Top 10 most-reviewed apps
# ---------------------------------------------------------
top_reviewed = df.nlargest(10, "reviews")[["app_name", "category", "rating", "reviews", "installs"]]

# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------
summary = {
    "n_apps": len(df),
    "avg_rating": df["rating"].mean(),
    "median_installs": int(df["installs"].median()),
    "pct_free": (df["type"] == "Free").mean() * 100,
    "pct_paid": (df["type"] == "Paid").mean() * 100,
    "free_avg_rating": free_avg_rating,
    "paid_avg_rating": paid_avg_rating,
    "top_category_by_count": cat_counts.index[0],
    "top_category_by_installs": installs_by_cat.index[0],
    "avg_size_mb": df["size_mb"].mean(),
    "corr_reviews_installs": float(df["reviews"].corr(df["installs"])),
    "corr_size_rating": float(df["size_mb"].corr(df["rating"])),
    "top_reviewed_app": top_reviewed.iloc[0]["app_name"],
}

with open("summary_metrics.json", "w") as f:
    json.dump(summary, f, indent=2, default=str)

print("\nSUMMARY")
print(json.dumps(summary, indent=2, default=str))
print("\nSaved summary_metrics.json and charts/*.png")
